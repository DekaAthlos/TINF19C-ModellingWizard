Dies ist die Dokumentation zu dem Plugin ModellingWizard für AutomationML.

Um die Dokumentation anzeigen zu lassen befolgen Sie diese Schritte:

1. Entpacken Sie den Inhalt des .zip Files
2. Gehen Sie in das 'html' Verzeichnis
3. Öffnen sie die Datei mit dem Namen 'index.html'