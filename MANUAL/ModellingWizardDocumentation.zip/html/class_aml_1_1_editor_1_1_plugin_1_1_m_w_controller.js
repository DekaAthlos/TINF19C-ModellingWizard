var class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller =
[
    [ "MWGUIType", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#add13bd390b8d39fee5fb2b73d85ec6b0", [
      [ "CreateDevice", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#add13bd390b8d39fee5fb2b73d85ec6b0a08139fc253db7964964002703bda052e", null ],
      [ "CreateInterface", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#add13bd390b8d39fee5fb2b73d85ec6b0afd44e4ee14bded07d2f3dff42dea0f6e", null ],
      [ "Start", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#add13bd390b8d39fee5fb2b73d85ec6b0aa6122a65eaa676f700ae68d393054a37", null ],
      [ "DeviceDescription", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#add13bd390b8d39fee5fb2b73d85ec6b0a5d2adcfd71637096d3d16648971c33c5", null ]
    ] ],
    [ "MWController", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#a9c87165813d6f480fb4d1141de016565", null ],
    [ "ChangeGui", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#aa613a0bc4392c195c617dcd7aba257f5", null ],
    [ "CreateDeviceOnClick", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#ad0432669e3a6e29aadfb7892746b5068", null ],
    [ "GetDeviceDescriptionForm", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#adba55c4a5135c58c69a0d92d495a0ad1", null ],
    [ "importFile", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html#ad2f99785d2a3b068dd3ce6c1d7f7fceb", null ]
];