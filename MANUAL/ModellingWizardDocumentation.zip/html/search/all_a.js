var searchData=
[
  ['name_125',['Name',['../class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_data_grid_views.html#a2b05161d540d7cd91ae360c5d3ce931d',1,'Aml.Editor.Plugin.ClassOfListsFromDataGridViews.Name()'],['../class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_referencefile.html#a615ebad7839429334256ad90d985b1e3',1,'Aml.Editor.Plugin.ClassOfListsFromReferencefile.Name()']]]
];
