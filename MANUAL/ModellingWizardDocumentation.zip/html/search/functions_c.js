var searchData=
[
  ['windowsizechanger_287',['WindowSizeChanger',['../class_aml_1_1_editor_1_1_plugin_1_1_animation_class.html#ad95b75f8f5095b88ef3aa75d92e25263',1,'Aml.Editor.Plugin.AnimationClass.WindowSizeChanger(Panel panelNumber, Button buttonNumber)'],['../class_aml_1_1_editor_1_1_plugin_1_1_animation_class.html#ae9de03fc8ff4839dff7873a64d5eaf8c',1,'Aml.Editor.Plugin.AnimationClass.WindowSizeChanger(Panel panelNumber)']]]
];
