var files_dup =
[
    [ "About.xaml.cs", "_about_8xaml_8cs.html", [
      [ "About", "class_aml_1_1_editor_1_1_plugin_1_1_about.html", "class_aml_1_1_editor_1_1_plugin_1_1_about" ]
    ] ],
    [ "AnimationClass.cs", "_animation_class_8cs.html", [
      [ "AnimationClass", "class_aml_1_1_editor_1_1_plugin_1_1_animation_class.html", "class_aml_1_1_editor_1_1_plugin_1_1_animation_class" ]
    ] ],
    [ "AutomationMLDataTables.cs", "_automation_m_l_data_tables_8cs.html", [
      [ "AutomationMLDataTables", "class_aml_1_1_editor_1_1_plugin_1_1_automation_m_l_data_tables.html", "class_aml_1_1_editor_1_1_plugin_1_1_automation_m_l_data_tables" ]
    ] ],
    [ "ClassOfListsFromDataGridViews.cs", "_class_of_lists_from_data_grid_views_8cs.html", [
      [ "ClassOfListsFromDataGridViews", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_data_grid_views.html", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_data_grid_views" ]
    ] ],
    [ "ClassOfListsFromReferencefile.cs", "_class_of_lists_from_referencefile_8cs.html", [
      [ "ClassOfListsFromReferencefile", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_referencefile.html", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_referencefile" ]
    ] ],
    [ "DeviceDescription.cs", "_device_description_8cs.html", [
      [ "DeviceDescription", "class_aml_1_1_editor_1_1_plugin_1_1_device_description.html", "class_aml_1_1_editor_1_1_plugin_1_1_device_description" ]
    ] ],
    [ "DeviceDescription.Designer.cs", "_device_description_8_designer_8cs.html", [
      [ "DeviceDescription", "class_aml_1_1_editor_1_1_plugin_1_1_device_description.html", "class_aml_1_1_editor_1_1_plugin_1_1_device_description" ]
    ] ],
    [ "ModellingWizard.xaml.cs", "_modelling_wizard_8xaml_8cs.html", [
      [ "ModellingWizard", "class_aml_1_1_editor_1_1_plugin_1_1_modelling_wizard.html", "class_aml_1_1_editor_1_1_plugin_1_1_modelling_wizard" ]
    ] ],
    [ "MWController.cs", "_m_w_controller_8cs.html", [
      [ "MWController", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller" ]
    ] ],
    [ "MWData.cs", "_m_w_data_8cs.html", [
      [ "MWData", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_data.html", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_data" ],
      [ "MWObject", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_data_1_1_m_w_object.html", null ]
    ] ],
    [ "MWDevice.cs", "_m_w_device_8cs.html", [
      [ "MWDevice", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_device.html", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_device" ],
      [ "DataGridParameters", "class_aml_1_1_editor_1_1_plugin_1_1_data_grid_parameters.html", "class_aml_1_1_editor_1_1_plugin_1_1_data_grid_parameters" ],
      [ "ElectricalParameters", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters.html", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters" ],
      [ "ElectricalParametersInElectricalDataDataGridView", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters_in_electrical_data_data_grid_view.html", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters_in_electrical_data_data_grid_view" ],
      [ "PinParametersInPinInfoDataGridView", "class_aml_1_1_editor_1_1_plugin_1_1_pin_parameters_in_pin_info_data_grid_view.html", "class_aml_1_1_editor_1_1_plugin_1_1_pin_parameters_in_pin_info_data_grid_view" ],
      [ "AttachablesDataGridViewParameters", "class_aml_1_1_editor_1_1_plugin_1_1_attachables_data_grid_view_parameters.html", "class_aml_1_1_editor_1_1_plugin_1_1_attachables_data_grid_view_parameters" ],
      [ "ElectricalInterfaceParameters", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_interface_parameters.html", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_interface_parameters" ]
    ] ],
    [ "SearchAMLComponentFile.cs", "_search_a_m_l_component_file_8cs.html", [
      [ "SearchAMLComponentFile", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_component_file.html", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_component_file" ]
    ] ],
    [ "SearchAMLLibraryFile.cs", "_search_a_m_l_library_file_8cs.html", [
      [ "SearchAMLLibraryFile", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_library_file.html", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_library_file" ]
    ] ]
];