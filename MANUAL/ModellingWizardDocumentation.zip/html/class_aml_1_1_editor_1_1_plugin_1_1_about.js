var class_aml_1_1_editor_1_1_plugin_1_1_about =
[
    [ "About", "class_aml_1_1_editor_1_1_plugin_1_1_about.html#a0001137d5fb3972b81264ce5568cc4d8", null ],
    [ "Version", "class_aml_1_1_editor_1_1_plugin_1_1_about.html#a542282bf537e261e5294e607f88dc9e6", null ]
];