var hierarchy =
[
    [ "Aml.Editor.Plugin.AnimationClass", "class_aml_1_1_editor_1_1_plugin_1_1_animation_class.html", null ],
    [ "Aml.Editor.Plugin.AttachablesDataGridViewParameters", "class_aml_1_1_editor_1_1_plugin_1_1_attachables_data_grid_view_parameters.html", null ],
    [ "Aml.Editor.Plugin.AutomationMLDataTables", "class_aml_1_1_editor_1_1_plugin_1_1_automation_m_l_data_tables.html", null ],
    [ "Aml.Editor.Plugin.ClassOfListsFromDataGridViews", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_data_grid_views.html", null ],
    [ "Aml.Editor.Plugin.ClassOfListsFromReferencefile", "class_aml_1_1_editor_1_1_plugin_1_1_class_of_lists_from_referencefile.html", null ],
    [ "Aml.Editor.Plugin.DataGridParameters", "class_aml_1_1_editor_1_1_plugin_1_1_data_grid_parameters.html", null ],
    [ "Aml.Editor.Plugin.ElectricalInterfaceParameters", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_interface_parameters.html", null ],
    [ "Aml.Editor.Plugin.ElectricalParameters", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters.html", null ],
    [ "Aml.Editor.Plugin.ElectricalParametersInElectricalDataDataGridView", "class_aml_1_1_editor_1_1_plugin_1_1_electrical_parameters_in_electrical_data_data_grid_view.html", null ],
    [ "IAMLEditorView", null, [
      [ "Aml.Editor.Plugin.ModellingWizard", "class_aml_1_1_editor_1_1_plugin_1_1_modelling_wizard.html", null ]
    ] ],
    [ "Aml.Editor.Plugin.MWController", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_controller.html", null ],
    [ "Aml.Editor.Plugin.MWData.MWObject", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_data_1_1_m_w_object.html", [
      [ "Aml.Editor.Plugin.MWDevice", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_device.html", null ]
    ] ],
    [ "Aml.Editor.Plugin.PinParametersInPinInfoDataGridView", "class_aml_1_1_editor_1_1_plugin_1_1_pin_parameters_in_pin_info_data_grid_view.html", null ],
    [ "Aml.Editor.Plugin.SearchAMLComponentFile", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_component_file.html", null ],
    [ "Aml.Editor.Plugin.SearchAMLLibraryFile", "class_aml_1_1_editor_1_1_plugin_1_1_search_a_m_l_library_file.html", null ],
    [ "UserControl", null, [
      [ "Aml.Editor.Plugin.DeviceDescription", "class_aml_1_1_editor_1_1_plugin_1_1_device_description.html", [
        [ "Aml.Editor.Plugin.MWData", "class_aml_1_1_editor_1_1_plugin_1_1_m_w_data.html", null ]
      ] ],
      [ "Aml.Editor.Plugin.ModellingWizard", "class_aml_1_1_editor_1_1_plugin_1_1_modelling_wizard.html", null ]
    ] ],
    [ "Window", null, [
      [ "Aml.Editor.Plugin.About", "class_aml_1_1_editor_1_1_plugin_1_1_about.html", null ]
    ] ]
];